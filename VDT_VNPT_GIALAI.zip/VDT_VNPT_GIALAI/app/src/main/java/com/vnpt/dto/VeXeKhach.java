package com.vnpt.dto;

public class VeXeKhach {
    private String tuyenDuong;
    private String SoGhe;
    private String tgKhoiHanh;
    private String soXe;

    public VeXeKhach() {
    }

    public String getTuyenDuong() {
        return tuyenDuong;
    }

    public void setTuyenDuong(String tuyenDuong) {
        this.tuyenDuong = tuyenDuong;
    }

    public String getSoGhe() {
        return SoGhe;
    }

    public void setSoGhe(String soGhe) {
        SoGhe = soGhe;
    }

    public String getTgKhoiHanh() {
        return tgKhoiHanh;
    }

    public void setTgKhoiHanh(String tgKhoiHanh) {
        this.tgKhoiHanh = tgKhoiHanh;
    }

    public String getSoXe() {
        return soXe;
    }

    public void setSoXe(String soXe) {
        this.soXe = soXe;
    }
}
