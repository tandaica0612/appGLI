package com.vnpt.dto;

public class Term {
	private int id_term;
	private String name_term;
	public int getId_term() {
		return id_term;
	}
	public void setId_term(int id_term) {
		this.id_term = id_term;
	}
	public String getName_term() {
		return name_term;
	}
	public void setName_term(String name_term) {
		this.name_term = name_term;
	}
}
