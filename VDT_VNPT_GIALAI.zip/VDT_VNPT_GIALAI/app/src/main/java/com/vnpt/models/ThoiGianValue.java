package com.vnpt.models;



public class ThoiGianValue {
    private String TU_NGAY = "";
    private String DEN_NGAY = "";
    public String getTU_NGAY() {
        return TU_NGAY;
    }

    public void setTU_NGAY(String TU_NGAY) {
        this.TU_NGAY = TU_NGAY;
    }

    public String getDEN_NGAY() {
        return DEN_NGAY;
    }

    public void setDEN_NGAY(String DEN_NGAY) {
        this.DEN_NGAY = DEN_NGAY;
    }


}
